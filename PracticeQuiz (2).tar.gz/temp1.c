#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void main() {
  char pin[256];
  printf("Start to guess the pin:\n> ");

  scanf("%s", pin);
  /* printf("%s\n", pin); */

  if ( strcmp(pin, "gzliilzg") == 0 ) {
    /* Print out "You got it!" on screen */
    printf("You got it!\n");
  }
  else {
    /* Print out "You missed it!" on screen */
    printf("You missed it!\n");
  }
}
