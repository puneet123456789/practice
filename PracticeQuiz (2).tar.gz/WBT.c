#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

void main(int argc, char *argv[]) {
  char input;

  printf("Hello, I am Dr. Naive. I developted this ATM machine simulator, can you run White Box Testing for me?\n");

  input = getc(stdin);
  switch (input) {
    case '1':
      printf("You got 20 dollars!\n");
      break;
    case '2':
      printf("You got 40 dollars!\n");
      break;
    case '3':
      printf("You got 60 dollars!\n");
    case '4':
      printf("You got 80 dollars!\n");
      break;
    default:
      printf("You type in the wrong selection!\n");
      break;
  }
}

